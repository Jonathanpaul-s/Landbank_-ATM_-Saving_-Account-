=====================================================================================
How to install and Crack:
(Pictures Included)
1) Install the program by default
2) End the program via Tray (End Program by Taskmgr.exe)
3) Copy the crack to the folder: "(C:\Program Files (x86)\ManyCam\imageformats)"
4) Open Manycam and ENJOY!!!
=====================================================================================
By N-KrYpT